
/***************************************************************************************
 * Return the PartTreeMatchType string value for the specified eMatchType constant
 * @param {Integer} eMatchType the specified MatchType constant
 * @return {String} PartTreeMatchType string value or "N/A" is unassigned or invalid 
 **************************************************************************************/
function getPartTreeMatchType(eMatchType) {
  var result = "N/A";
  try {
    var iMatchType = toInt(eMatchType);
    if (!isNaN(iMatchType))  {
      switch (iMatchType) {
        case 0:
          result = "NoMatch";
          break;
        case 1:
          result = "OffLine";
          break;
        case 2:
          result = "OffStart";
          break;
        case 3:
          result = "OffEnd";
          break;
        case 4:
          result = "Found";
          break;
      }
    }
  } catch(exp) {    
  }
  return result;
}

/*************************************************************************************
 * Class[MeterConverter:AppObject] (requires globals.js)
 * An Enum type class with static instances to convert units to and from meters
 *************************************************************************************/
/**
 * The Conversion Factor from the specified units to Meters (e.g. factor for Feet=0.3048)
 * @param {Number} factor
 * @returns {MeterConverter}
 */
MeterConverter.baseClass = AppObject;
MeterConverter.className = "MeterConverter";
function MeterConverter(factor) {
  this.inheritsFrom = MeterConverter.baseClass;
  this.inheritsFrom();
  this.setClassReferences(MeterConverter, MeterConverter.baseClass);

  /**
   * Default = null
   * @type Number
   */
  var mdFactor = 1.0;
  mdFactor = toFloat(factor);
  if ((isNaN(mdFactor)) || (mdFactor === 0.0)) {
    mdFactor = 1.0;
  }

  this.fromMeters = function() {
    return 1/mdFactor;
  };
  
  this.toMeters = function() {
    return mdFactor;
  };
}
MeterConverter.Meters = new MeterConverter(1.0);
MeterConverter.Inches = new MeterConverter(0.3048/12);
MeterConverter.Feet = new MeterConverter(0.3048);
MeterConverter.Yards = new MeterConverter(3*0.3048);
MeterConverter.Miles = new MeterConverter(1609.344);
MeterConverter.MilliMeters = new MeterConverter(0.001);
MeterConverter.KiloMeters = new MeterConverter(1000.0);

/*************************************************************************************
 * Class[PtSearchRecord:AppObject] (requires globals.js)
 * 
 *************************************************************************************/
PtSearchRecord.baseClass = AppObject;
PtSearchRecord.className = "PtSearchRecord";
PtSearchRecord.count = 0;
function PtSearchRecord() {
  this.inheritsFrom = PtSearchRecord.baseClass;
  this.inheritsFrom();
  this.setClassReferences(PtSearchRecord, PtSearchRecord.baseClass);
  this.objName="PtSearchRecord"+PtSearchRecord.count++;
  eval(this.objName+"=this");

  /**
   * Default= PtSearchRecord.count
   * @type Integer */
  var miRecordId = PtSearchRecord.count;
  /**
   * Default= null
   * @type String */
  var msSysId = "";
  /**
   * Default= null
   * @type String */
  var msSysName = "";
  /**
   * Default= null
   * @type String */
  var msSegId = "";
  /**
   * Default= null
   * @type String */
  var msSegName = "";
  /**
   * Default= Number.NaN
   * @type Double */
  var mdXCoord = Number.NaN;
  /**
   * Default= Number.NaN
   * @type Double */
  var mdYCoord = Number.NaN;
  /**
   * Default = false
   * @type Boolean
   */
  var mbHasMatch = false;
  /**
   * Default = Number.NaN
   * @type Double */
  var mdMarkerDist = Number.NaN;
  /**
   * Default=Number.NaN
   * @type Double  */
  var mdMatchDist = Number.NaN;
  /**
   * Default = Number.NaN
   * @type Integer */
  var meMatchType = Number.NaN;
  
  /**
   * Get the Record's RecordId
   * @returns {Integer} return assigend avleu or null
   */
  this.getRecordId = function() {
    return miRecordId;
  };
  
  /**
   * Set the Record's RecordId
   * @param {Integer} recordId
   * @returns {void}
   */
  this.setRecordId = function(recordId) {
    miRecordId = toInt(recordId);
  };
  
  /**
   * Get the Record's Search System ID
   * @returns {String}
   */
  this.getSystemId = function() {
    return msSysId;
  };
  
  /**
   * Set the Record's Search System ID
   * @param {String} sysId
   * @returns {void}
   */
  this.setSystemId = function(sysId) {
    msSysId = allTrim(sysId);
  };
    
  /**
   * Get the Record's Search System Name
   * @returns {String}
   */
  this.getSystemName = function() {
    return msSysName;
  };
  
  /**
   * Set the Record's Search System Name
   * @param {String} sysName
   * @returns {void}
   */
  this.setSystemName = function(sysName) {
    msSysName = allTrim(sysName);
  };
  
  /**
   * Get the Record's Search Segment ID
   * @returns {String}
   */
  this.getSegmentId = function() {
    return msSegId;
  };
  
  /**
   * Set the Record's Search Segment ID
   * @param {String} segId
   * @returns {void}
   */
  this.setSegmentId = function(segId) {
    msSegId = allTrim(segId);
  };
    
  /**
   * Get the Record's Search Segment Name
   * @returns {String}
   */
  this.getSegmentName = function() {
    return msSegName;
  };
  
  /**
   * Set the Record's Search Segment Name
   * @param {String} segName
   * @returns {void}
   */
  this.setSegmentName = function(segName) {
    msSegName = allTrim(segName);
  };
  
  /**
   * Get the Record's XCoord
   * @returns {Double}
   */
  this.getXCoord = function() {
    return mdXCoord;
  };
  /**
   * Get the Record's YCoord
   * @returns {Double}
   */
  this.getXCoordText = function() {
    return ((mdXCoord === null) || (isNaN(mdXCoord)))? 
              "-": mdXCoord.toFixed(6);
  };
  /**
   * Set the Record's XCoord
   * @param {Double} coord
   * @returns {void}
   */
  this.setXCoord = function(coord) {
    mdXCoord = toFloat(coord);
  };
  
  /**
   * Get the Record's YCoord
   * @returns {Double}
   */
  this.getYCoord = function() {
    return mdYCoord;
  };
  /**
   * Get the Record's YCoord
   * @returns {Double}
   */
  this.getYCoordText = function() {
    return ((mdYCoord === null) || (isNaN(mdYCoord)))? 
              "-": mdYCoord.toFixed(6);
  };
  /**
   * Set the Record's YCoord
   * @param {Double} coord
   * @returns {void}
   */
  this.setYCoord = function(coord) {
    mdYCoord = toFloat(coord);
  };
  
  /**
   * Get the Record's HasMatch flag
   * @returns {Boolean}
   */
  this.getHasMatch = function() {
    return mbHasMatch;
  };
  
  /**
   * Set the Record's HasMatch flag
   * @param {Boolean|String} flag
   * @returns {void}
   */
  this.setHasMatch = function(flag) {
    mbHasMatch = toBool(flag);
  };
  
  /**
   * Get the Record's MarkerDistance (in feet)
   * @returns {Double}
   */
  this.getMarkerDistance = function() {
    return mdMarkerDist;
  };
  
  /**
   * Get the Record's MatchDistance in text format
   * @param {MeterConverter} converter
   * @param {integer} decimals
   * @returns {String}
   */
  this.getMarkerDistText = function(converter, decimals) {
    var result = "";
    /**
     * @type Number */
    var outVal = mdMarkerDist;
    if ((outVal !== null) && (!isNaN(outVal)) && (outVal > -999.00)) {
      var convertClass = (converter === null)? null: converter.getClass().className;
      eval("convertClass = (converter === null)? null: converter.getClass().className;");
      if ((convertClass !== null) && (convertClass === "MeterConverter")) {
        var newVal = null;
        newVal = (outVal * MeterConverter.Feet.toMeters());
        eval("newVal = (newVal * converter.fromMeters());");
        if (newVal !== null) {
          outVal = newVal;
        }
      } 
    }    
    var digits = (outVal <= -999.00)? 2: toInt(decimals);
    digits = ((isNaN(digits)) || (digits < 0))? 3: digits;
    return ((outVal === null) || (isNaN(outVal)))? 
              "-": outVal.toFixed(digits);
  };
  
  /**
   * Set the Record's MarkerDistance
   * @param {Float} distance (in miles)
   * @returns {void}
   */
  this.setMarkerDistance = function(distance) {
    mdMarkerDist = toFloat(distance);
  };
  
  /**
   * Get the Record's MatchDistance
   * @returns {Double} in miles
   */
  this.getMatchDistance = function() {
    return mdMatchDist;
  };
  
  /**
   * Get the Record's MatchDistance in text format 
   * @returns {String} formatted in feet
   */
  this.getMatchDistText = function() {
    return ((mdMatchDist === null) || (isNaN(mdMatchDist)))? 
        "-": mdMatchDist.toFixed(2);
  };
  /**
   * Set the Record's MatchDistance
   * @param {Double} distance (in feet)
   * @returns {void} 
   */
  this.setMatchDistance = function(distance) {
    mdMatchDist = toFloat(distance);
  };
  
  /**
   * Get the Record's MatchType
   * @returns {Integer}
   */
  this.getMatchType = function() {
    return meMatchType;
  };
  
  /**
   * Set the Record's MatchType
   * @param {Integer} eType
   * @returns {void}
   */
  this.setMatchType = function(eType) {
    meMatchType =  toInt(eType);
  };
  
  /**
   * Get the Record's MatchType Text value
   * @returns {String}
   */
  this.getMatchTypeText = function() {
    return getPartTreeMatchType(meMatchType);
  };
  
  /**
   * <p>Get the formated URL path - with assigned Query Parameters for WebService's 
   * findmatch request. The path is:<p>
   *  <code>"/findmatch/{soruceId}/{calcOption}?x={mdXCoord}&y=
   *  {mdYCoord}(&segid={msTreeId})(&buffer={buffer})"
   *  </code>
   * <p>The last term is only included it the Tree ID is specified</p>
   * @param {String} sourceId - required
   * @param {Integer} calcOption - required
   * @param (Double) buffer - optional
   * @returns {String} the formatted path.
   */
  this.getFindMatchPath = function(sourceId, calcOption, buffer) {
    var result = "/findmatch/";
    try {
      sourceId = allTrim(sourceId);
      if (sourceId.length === 0) {
        throw new Error("The Source ID is not selected.")
      }
      var iOption  = toInt(calcOption);
      if (isNaN(iOption)) {
        throw new Error("The Calc Option is not selected.")
      }
      result += sourceId + "/" + iOption;
      
      if (isNaN(mdXCoord)) {
        throw new Error("The Point of interest's X-Coodinate is not entered.")
      }
      if (isNaN(mdYCoord)) {
        throw new Error("The Point of interest's X-Coodinate is not entered.")
      }
      
      result += "?x=" + mdXCoord.toFixed(6);
      result += "&y=" + mdYCoord.toFixed(6);
      if ((msSegId !== null) && (msSegId.length > 0)) {
        result += "&segid=" +msSegId;
      }
      
      var srchBuffer = toFloat(buffer);
      if (!isNaN(srchBuffer)) {
        result += "&buffer=" + srchBuffer.toFixed(2);
      }
    } catch (exp) {
      result = null;
      alert("Find Match Path Error:\n" + exp.message);
    }
    return result;
  };
  
  /**
   * <p>Get the formated URL path - with assigned Query Parameters for WebService's 
   * calcxy request. The path is:<p>
   *  <code>"/calcxy/{sourceId}/{calcOption}?id={msTreeId}&amrkerx={mdMarkerDist}
   *  (&buffer={buffer})"
   *  </code>
   * @param {String} sourceId - required
   * @param {integer} calcOption - required
   * @param (Double) buffer - optional
   * @returns {String} the formatted path.
   */
  this.getCalcXYPath = function(sourceId, calcOption, buffer) {
    var result = "/calcxy/";
    try {
      sourceId = allTrim(sourceId);
      if (sourceId.length === 0) {
        throw new Error("The Source ID is not selected.")
      }
      var iOption  = toInt(calcOption);
      if (isNaN(iOption)) {
        throw new Error("The Calc Option is not selected.")
      }
      result += sourceId + "/" + iOption;
      
      if ((msSegId === null) || (msSegId.length === 0)) {
        throw new Error("Please enter the Tree ID and try again.")
      }
      if (isNaN(mdMarkerDist)) {
        throw new Error("Please enter the Marker Distance and try again.")
      }
      result += "?segid=" + msSegId;
      result += "&markerx=" + mdMarkerDist.toFixed(4);
      
      var srchBuffer = toFloat(buffer);
      if (!isNaN(srchBuffer)) {
        result += "&buffer=" + srchBuffer.toFixed(2);
      }
    } catch (err) {
      result = null;
      alert("CalcXY Path Error:\n" + err.message);
    }
    return result;
  };
  
  /**
   * Clled to clear all match parameters (i.e., hasMatch, MarkerDistance, MatchDistacne,
   * and MatchType.
   * @returns {undefined}
   */
  this.clearFindMatch = function() {
    mbHasMatch = false;
    msSysId = null;
    msSysName = null;
    msSegId = null;
    msSegName = null;
    mdMarkerDist = Number.NaN;
    mdMatchDist = Number.NaN;
    meMatchType = Number.NaN;
  };
  
  /**
   * Clled to clear all match parameters (i.e., hasMatch, MarkerDistance, MatchDistacne,
   * and MatchType.
   * @returns {undefined}
   */
  this.clearCalcXY = function() {
    msSysId = null;
    msSysName = null;
    msSegId = null;
    msSegName = null;
    mdXCoord = Number.NaN;
    mdYCoord = Number.NaN;
    mbHasMatch = false;
    mdMarkerDist = Number.NaN;
    mdMatchDist = Number.NaN;
    meMatchType = Number.NaN;
  };
  
  /**
   * <p>Called to parse input queryStr (in the format "{par1}={value1}&{par2}={value2}&.."
   * it will update only the values included in the queryStr.</p>
   * <p><b>NOTE:</b> it does not reset the value before teh update start. Call the
   * clearFindMatch or clearCalcXY method to clear the results of the calls before parsing
   * the Results.</p>
   * @param {String} queryStr the input string
   * @returns {void}
   */
  this.parseTextResult = function(queryStr) {
    /**
     * @type QueryParamDict
     */    
    var qryDict = new QueryParamDict();
    qryDict.parse(queryStr);
    if (qryDict.count() === 0) {
      return;
    }    
    /**
     * @type QueryParam
     */
    var param = qryDict.findParam("sysid");
    if (param !== null) {
      this.setSystemId(param.getValue());
    }
    param = qryDict.findParam("sysname");
    if (param !== null) {
      this.setSystemName(param.getValue());
    }
    param = qryDict.findParam("segid");
    if (param !== null) {
      this.setSegmentId(param.getValue());
    }
    param = qryDict.findParam("segname");
    if (param !== null) {
      this.setSegmentName(param.getValue());
    }
    param = qryDict.findParam("x");
    if (param !== null) {
      this.setXCoord(param.getValue());
    }
    param = qryDict.findParam("y");
    if (param !== null) {
      this.setYCoord(param.getValue());
    }
    param = qryDict.findParam("markerx");
    if (param !== null) {
      this.setMarkerDistance(param.getValue());
    }
    param = qryDict.findParam("markery");
    if (param !== null) {
      this.setMatchDistance(param.getValue());
    }
    param = qryDict.findParam("hasmatch");
    if (param !== null) {
      this.setHasMatch(param.getValue());
    }
    param = qryDict.findParam("matchtype");
    if (param !== null) {
      this.setMatchType(param.getValue());
    }
  };
}
/*************************************************************************************
 * Class[PtSearchRecord:AppObject] (requires globals.js)
 * 
 *************************************************************************************/
QueryParam.baseClass = AppObject;
QueryParam.className = "QueryParam";
function QueryParam() {
  this.inheritsFrom = QueryParam.baseClass;
  this.inheritsFrom();
  this.setClassReferences(QueryParam, QueryParam.baseClass);
  
  /**
   * The Parameter Name
   * @type String
   */
  var msName = "";
  /**
   * The Parameter value (as a string)
   * @type String
   */
  var msValue = "";
  
  /**
   * Set the Parameter Name and Value
   * @param {String} parName
   * @param {String} parValue
   * @returns {void}
   */
  this.set = function(parName, parValue) {
    parName = allTrim(parName);
    if (parName.length === 0) {
      throw new Error("The QueryParameter Name cannot be empty.")
    }
    msName = parName;
    msValue = allTrim(parValue);
  };
  
  /**
   * Get the parameter name
   * @returns {String}
   */
  this.getName = function() {
    return msName;
  };
  
  /**
   * Get the parameter value
   * @returns {String}
   */
  this.getValue = function() {
    return msValue;
  };
  
  /**
   * Get the parameter value
   * @param {String} parValue the new Parameter Value
   * @returns {String}
   */
  this.setValue = function(parValue) {
    msValue = allTrim(parValue);
  };
  
  /**
   * Get the parameter string {name}={value}
   * @returns {String} return encoded string or "" if the name is undefined.
   */
  this.queryString = function() {
    var result = "";
    if (msName.length > 0) {
      result = escape(msName) + "=";
      if (msValue.length > 0) {
        result += escape(msValue);
      }
    }
    return result;
  };
  
  /**
   * Called to parse the QueryParam's name and value from the query string. The apresed 
   * values are unescaped (decoded). The name and value are set to "" if inStr="" or the
   * parameter name is undefined.
   * @param {String} inStr
   * @returns {void}
   */
  this.parse = function(inStr) {
    msName = "";
    msValue = "";
    inStr = allTrim(inStr);
    if (inStr.length > 0) {
      var strArr = inStr.split("=");
      msName = (strArr.length > 0)? allTrim(unescape(strArr[0])): "";
      if ((msName.length > 0) && (strArr.length > 1)) {
        msValue = allTrim(unescape(strArr[1]));
      }
    }
  };
}
/*************************************************************************************
 * Class[QueryParamDict:AppObject] (requires globals.js)
 * A Dictionary of QueryParams
 *************************************************************************************/
QueryParamDict.baseClass = AppObject;
QueryParamDict.className = "QueryParamDict";
function QueryParamDict() {
  this.inheritsFrom = QueryParamDict.baseClass;
  this.inheritsFrom();
  this.setClassReferences(QueryParamDict, QueryParamDict.baseClass);
  
  /*
   * default is an empty array
   * @type Array
   */
  var mpParams = new Array();
  
  /**
   * Add a new parameter to the Dictionary
   * @param {String} parName - required
   * @param {String} parValue - can be null|""
   * @returns {void}
   */
  this.add = function(parName, parValue) {
    /**
     * @type QueryParam
     */
    var param = this.findParam(parName);
    if (param !== null) {
      param.setValue(parValue);
    } else {
      param = new QueryParam();
      param.set(parName,parValue);
      if (param.getName().length === 0) {
        return;
      }
      mpParams.push(param);
    }
  };
  
  /**
   * Find the QueryParam by its Parameter Name
   * @param {String} parName
   * @returns {QueryParam}
   */
  this.findParam = function(parName) {
    var result = null;
    parName = allTrim(parName).toLowerCase();
    if ((parName.length > 0) && (mpParams.length > 0)) {
      for (var i = 0; i < mpParams.length; i++) {
        /**
         * @type QueryParam
         */
        var param = mpParams[i];
        if ((param !== null) && (param.getName().toLowerCase() === parName)) {
          result = param;
          break;
        }
      }
    }    
    return result;
  };
  
  /**
   * Get the QueryParam[parName]'s Value
   * @param {String} parName the QueryParam.Name
   * @returns {String} teh assigned value or "" if unable to locate the parameter
   */
  this.getValue = function(parName) {
    var result = "";
    /**
     * @type QueryParam
     */
    var param = this.findParam(parName);
    if (param !== null) {
      result = param.getValue();
    }
    return result;
  };
  
  /**
   * Get the QueryParam by index.
   * @param {type} index
   * @returns {QueryParam} the QueryParam at the index or null if index isNaN ot out of
   * bounds.
   */
  this.get = function(index) {
    var result = null;
    index = toInt(index);
    if ((!isNaN(index)) && (index >= 0) && (index <= this.count())) {
      result = mpParams[index];
    }
    return result;
  };
  
  /**
   * Get the number of parameters in teh dictionary
   * @returns {Integer}
   */
  this.count = function() {
    return mpParams.length;
  };
  
  /**
   * Claer teh dictionary
   * @returns {void}
   */
  this.clear = function() {
    mpParams = new Array();
  };
  
  /**
   * Get the Query String that include all parameters
   * @returns {String} the formatted query string without the starting "?".
   */
  this.queryString = function() {
    var result = "";
    if (this.count() > 0) {
      for (var i=0; i < mpParams.length; i++) {
        /**
         * @type QueryParam
         */
        var param = mpParams[i];
        /**
         * @type String
         */
        var qryStr = param.queryString();
        if (qryStr.length > 0) {
          if (result.length === 0) {
            result = qryStr;
          } else {
            result += "&" + qryStr;
          }
        }
      }
    }
    return result;
  };  
  
  /**
   * Called to initiate the Dictioanry from a Query String
   * @param {String} inStr the input query string
   * @returns {integer} the number of parsed parameters
   */
  this.parse = function(inStr) {
    this.clear();
    inStr = allTrim(inStr);
    inStr = inStr.replace("?","");
    if (inStr.length === 0) {
      return;
    }
    
    var strArr = inStr.split("&");
    if (strArr.length > 0) {
      for (var i=0; i < strArr.length; i++) {
        var param = new QueryParam();
        param.parse(strArr[i]);
        if (param.getName().length > 0) {
          mpParams.push(param);
        }
      }
    }
    return this.count();
  };
}

/*
 * Support js
 */
var rjsSupport = {
  proxy: "",
  getHttpProxy: function() {
    return this.proxy;
  },
  setHttpProxy: function(proxy_) {
    this.proxy = proxy_;
  },
  isSetHttpProxy: function() {
    return this.getHttpProxy().length > 0;
  },
  getHttpRequest: function() {
    var xmlHttpReq;
    try
    {    // Firefox, Opera 8.0+, Safari, IE7.0+
      xmlHttpReq = new XMLHttpRequest();
    }
    catch (e)
    {    // Internet Explorer 6.0+, 5.0+
      try
      {
        xmlHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
      }
      catch (e)
      {
        try
        {
          xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (e)
        {
          this.debug("Your browser does not support AJAX!");
        }
      }
    }
    return xmlHttpReq;
  },
  findUrl: function(url, method) {
    var url2 = url;
    if (this.isSetHttpProxy())
      url2 = this.getHttpProxy() + "?method=" + method + "&url=" + url2;
    return url2;
  },
  findMethod: function(method) {
    var method2 = method;
    if ((method != "GET") && (this.isSetHttpProxy())) {
      method2 = "POST";
    }
    return method2;
  },
  open: function(method2, url2, mimeType, paramLen, async) {
    
    //Change url and method if using http proxy
    var url = this.findUrl(url2, method2);
    var method = this.findMethod(method2);
    
    //add timestamp to make url unique in case of IE7
    var timestamp = new Date().getTime();
    if (url.indexOf("?") !== -1)
      url = url + "&timestamp=" + timestamp;
    else
      url = url + "?timestamp=" + timestamp;
    
    var xmlHttpReq = this.getHttpRequest();
    if (xmlHttpReq === null) {
      this.debug('Error: Cannot create XMLHttpRequest');
      return null;
    }
    try {
      netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
    } catch (e) {
      //this.debug("Permission UniversalBrowserRead denied.");
    }
    try {
      xmlHttpReq.open(method, url, async);
    } catch (e) {
      this.debug('Error: XMLHttpRequest.open failed for: ' + url + ' Error name: ' + e.name + ' Error message: ' + e.message);
      return null;
    }
    if (mimeType != null) {
      if (method == 'GET') {
        //this.debug("setting GET accept: "+mimeType);
        xmlHttpReq.setRequestHeader('Accept', mimeType);
      } else if (method == 'POST' || method == 'PUT') {
        //this.debug("setting content-type: "+mimeType);
        //Send the proper header information along with the request
        xmlHttpReq.setRequestHeader("Content-Type", mimeType);
        xmlHttpReq.setRequestHeader("Content-Length", paramLen);
        xmlHttpReq.setRequestHeader("Connection", "close");
      }
    }
    //For cache control on IE7
    xmlHttpReq.setRequestHeader("Cache-Control", "no-cache");
    xmlHttpReq.setRequestHeader("Pragma", "no-cache");
    xmlHttpReq.setRequestHeader("Expires", "-1");
    
    return xmlHttpReq;
  },
  loadXml: function(xmlStr) {
    var doc2;
    // code for IE
    if (window.ActiveXObject)
    {
      doc2 = new ActiveXObject("Microsoft.XMLDOM");
      doc2.async = "false";
      doc2.loadXML(xmlStr);
    }
    // code for Mozilla, Firefox, Opera, etc.
    else
    {
      var parser = new DOMParser();
      doc2 = parser.parseFromString(xmlStr, getDefaultMime());
    }
    return doc2;
  },
  findIdFromUrl: function(u) {
    var li = u.lastIndexOf('/');
    if (li != -1) {
      var u2 = u.substring(0, li);      
      var li2 = u2.lastIndexOf('/');
      u2 = u.substring(0, li2);
      return u.substring(li2 + 1, li);
    }
    return -1;
  },
  get: function(url, mime) {
    var xmlHttpReq = this.open('GET', url, mime, 0, false);
    try {
      xmlHttpReq.send(null);
      if (xmlHttpReq.readyState == 4) {
        var rtext = xmlHttpReq.responseText;
        if (rtext == undefined || rtext == '' || rtext.indexOf('HTTP Status') != -1) {
          if (rtext != undefined)
            this.debug('Failed XHR(GET, ' + url + '): Server returned --> ' + rtext);
          return '-1';
        }
        return rtext;           
      }
    } catch (e) {
      this.debug('Caught Exception; name: [' + e.name + '] message: [' + e.message + ']');
    }
    return '-1';
  },
  post: function(url, mime, content) {
    var xmlHttpReq = this.open('POST', url, mime, content.length, false);
    try {
      xmlHttpReq.send(content);
      if (xmlHttpReq.readyState == 4) {
        var status = xmlHttpReq.status;
        if (status == 201) {
          return true;
        } else {
          this.debug('Failed XHR(POST, ' + url + '): Server returned --> ' + status);
        }
      }
    } catch (e) {
      this.debug('Caught Exception; name: [' + e.name + '] message: [' + e.message + ']');
    }
    return false;
  },
  put: function(url, mime, content) {
    var xmlHttpReq = this.open('PUT', url, mime, content.length, false);
    try {
      xmlHttpReq.send(content);
      if (xmlHttpReq.readyState == 4) {
        var status = xmlHttpReq.status;
        if (status == 204) {
          return true;
        } else {
          this.debug('Failed XHR(PUT, ' + url + '): Server returned --> ' + status);
        }
      }
    } catch (e) {
      this.debug('Caught Exception; name: [' + e.name + '] message: [' + e.message + ']');
    }
    return false;
  },
  delete_: function(url) {
    return this.delete_(url, 'application/xml', null);
  },
  delete_ : function(url, mime, content) {
    var length = 0;
    if (content != null && content != undefined) {
      length = content.length;
    }
    var xmlHttpReq = this.open('DELETE', url, mime, length, false);
    try {
      if (length == 0) {
        xmlHttpReq.send(null);
      }
      else {
        xmlHttpReq.send(content);
      }
      if (xmlHttpReq.readyState == 4) {
        var status = xmlHttpReq.status;
        if (status == 204) {
          return true;
        } else {
          this.debug('Failed XHR(DELETE, ' + url + '): Server returned --> ' + status);
        }
      }
    } catch (e) {
      this.debug('Caught Exception; name: [' + e.name + '] message: [' + e.message + ']');
    }
    return false;
          },
          debug: function(message) {
    var dbgComp = document.getElementById("dbgComp");
    if (dbgComp == null) {
      dbgComp = document.createElement("div");
      dbgComp.setAttribute("id", "dbgComp");
      dbgComp.style.border = "#2574B7 1px solid";
      dbgComp.style.font = "12pt/14pt sans-serif";
      var br = document.createElement("div");
      document.getElementsByTagName("body")[0].appendChild(br);
      br.innerHTML = '<br/><br/><br/>';
      document.getElementsByTagName("body")[0].appendChild(dbgComp);
      if ((typeof rjsConfig != "undefined") && rjsConfig.isDebug) {
        dbgComp.style.display = "";
      } else {
        dbgComp.style.display = "none";
      }
      var tab = 'width: 20px; border-right: #2574B7 1px solid; border-top: #2574B7 1px solid; border-left: #2574B7 1px solid; border-bottom: #2574B7 1px solid; color: #000000; text-align: center;';
      var addActionStr = '<div style="' + tab + '"><a style="text-decoration: none" href="javascript:rjsSupport.closeDebug()"><span style="color: red">X</span></a></div>';        
      dbgComp.innerHTML = '<table><tr><td><span style="color: blue">Rest Debug Window</span></td><td>' + addActionStr + '</td></tr></table><br/>';
    }
    var s = dbgComp.innerHTML;
    var now = new Date();
    var dateStr = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
    dbgComp.innerHTML = s + '<span style="color: red">rest debug(' + dateStr + '): </span>' + message + "<br/>";
  },
  closeDebug: function() {
    var dbgComp = document.getElementById("dbgComp");
    if (dbgComp != null) {
      dbgComp.style.display = "none";
      dbgComp.innerHTML = '';
    }
  }
}
